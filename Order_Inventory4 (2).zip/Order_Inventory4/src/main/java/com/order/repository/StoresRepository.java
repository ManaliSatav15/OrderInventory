package com.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.model.Stores;

public interface StoresRepository extends JpaRepository<Stores,Integer> {

}

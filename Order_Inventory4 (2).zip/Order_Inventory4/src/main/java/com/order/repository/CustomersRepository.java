package com.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.order.model.Customers;

public interface CustomersRepository extends JpaRepository<Customers,Integer> {

	/*
	 * @Query(value="select c from Customers c where c.email_address=?1")
	 * 
	 * public List<Customers> getCustomersByEmail(String Email) ;
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @Query(value="select o from Orders o where o.customers.customer_id =?1")
	 * 
	 * public Customers getCustomerOrders(int customerId);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @Query(value="select s from Shipments s where s.customers.customer_id =?1")
	 * 
	 * public Customers getCustomerShipments(int customerId);
	 * 
	 * 
	 */
	
}

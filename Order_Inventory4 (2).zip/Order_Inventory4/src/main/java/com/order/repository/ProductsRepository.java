package com.order.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.order.model.Products;

public interface ProductsRepository extends JpaRepository<Products,Integer> {
 List<Products> findByProductNameContaining(String productName);
	 
	 public List<Products> findByUnitPriceBetween(BigDecimal min, BigDecimal max);
	 //public List<Products> getSortedProductsByField(Sort sort);

	 public List<Products> findAll(Sort sort);

}

package com.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.model.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory,Integer>{

	
}

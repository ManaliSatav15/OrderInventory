package com.order.exception;

public class ShipmentNotFoundException extends Exception {
	String message;
	public ShipmentNotFoundException(String message)
	{
		this.message=message;
	}
	public String  getMessage() {
		return this.message;
	}

}

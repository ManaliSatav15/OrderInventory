// Products.java
package com.order.model;


import java.math.BigDecimal;
import java.util.*;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "PRODUCTS")

public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRODUCT_ID")
    private int productId;

    @Column(name = "PRODUCT_NAME",nullable=false)
    private String productName;

    @Column(name = "UNIT_PRICE",precision=10 ,scale=2,nullable=false)
    private BigDecimal unitPrice;

    @Column(name = "COLOUR ,DEFAULT null")
    private String colour;

    @Column(name = "BRAND",nullable=false)
    private String brand;

    @Column(name = "SIZE",nullable=false)
    private String size;

    @Column(name = "RATING",nullable=false)
    private Integer rating;

    @JsonIgnore
    @OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Inventory> inventory;

	@JsonIgnore
	 @OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade =CascadeType.ALL) 
	 private List<OrderItems> orderItems;
	 
    
	public long getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public List<Inventory> getInventory() {
		return inventory;
	}

	public void setInventory(List<Inventory> inventory) {
		this.inventory = inventory;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public List<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}

	
    
    
		
	
}

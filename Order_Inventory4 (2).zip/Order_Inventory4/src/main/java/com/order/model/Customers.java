package com.order.model;

import java.util.List;



import javax.persistence.CascadeType;

import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.FetchType;

import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;

import javax.persistence.Id;

import javax.persistence.OneToMany;

import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

 

@Entity
@Table(name="CUSTOMERS")
public class Customers {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	@Column(name="CUSTOMER_ID")
	private int customer_id;

	
	public List<Shipments> getShipments() {
		return shipments;
	}



	public void setShipments(List<Shipments> shipments) {
		this.shipments = shipments;
	}



	public List<Orders> getOrders() {
		return orders;
	}



	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}


   
	@Column(name="EMAIL_ADDRESS" ,nullable=false,unique=true)
	
	private String email_address;

	@Column(name="FULL_NAME", nullable=false)
	private String full_name;

	@OneToMany(mappedBy = "customers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Shipments> shipments;

	@OneToMany(mappedBy = "customers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonIgnore
    private List<Orders> orders;

	public int getCustomer_id() {

		return customer_id;

	}

 

	public void setCustomer_id(int customer_id) {

		this.customer_id = customer_id;

	}

 

	public String getEmail_address() {

		return email_address;

	}

 

	public void setEmail_address(String email_address) {

		this.email_address = email_address;

	}

 

	public String getFull_name() {

		return full_name;

	}

 

	public void setFull_name(String full_name) {

		this.full_name = full_name;

	}

	

	

	

}
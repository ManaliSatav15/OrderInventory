package com.order.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import com.order.exception.ShipmentNotFoundException;
import com.order.model.Shipments;

import com.order.repository.ShipmentsRepository;

public class ShipmentServiceImpl implements ShipmentService{

	@Autowired
	ShipmentsRepository shipmentsRepository;

	@Override
	public List<Shipments> getAllShipment() {
		return shipmentsRepository.findAll();
	}

	@Override
	public void createShipments(Shipments shipments) {
		 shipmentsRepository.save(shipments);

	}


	@Override
	public Shipments updateShipment(Shipments shipments) throws ShipmentNotFoundException {
		if(shipmentsRepository.findById(shipments.getShipment_id()).isEmpty())
			throw new ShipmentNotFoundException("the order with "+shipments.getShipment_id()+"does not extis");
		return shipmentsRepository.save(shipments);

	}

 

	@Override
	public void deleteShipments(int shipmentId) throws ShipmentNotFoundException {
		if(shipmentsRepository.findById(shipmentId).isEmpty())
			throw new ShipmentNotFoundException("the order with "+shipmentId+"does not extis");
		 shipmentsRepository.delete(shipmentsRepository.findById(shipmentId).get());

	}

	@Override
	public Shipments getshipmentById(int shipmentId) throws ShipmentNotFoundException {
		if(shipmentsRepository.findById(shipmentId).isEmpty())
			throw new ShipmentNotFoundException("the order with "+shipmentId+"does not extis");
		return shipmentsRepository.findById(shipmentId).get();
	}

	

 

	
}
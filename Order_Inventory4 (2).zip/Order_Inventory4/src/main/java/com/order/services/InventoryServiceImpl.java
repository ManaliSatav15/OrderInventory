package com.order.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.order.exception.InventoryNotFoundException;
import com.order.model.Inventory;

import com.order.repository.InventoryRepository;

public class InventoryServiceImpl implements InventoryService{

	@Autowired
	InventoryRepository inventoryRepository;
	
	

	@Override
	public List<Inventory> getAllInventory() {
		return inventoryRepository.findAll();
	}

	@Override
	public void createInventory(Inventory inventory) {
		 inventoryRepository.save(inventory);
		
	}

	@Override
	public Inventory updateInventory(Inventory inventory) throws InventoryNotFoundException {
		if(inventoryRepository.findById(inventory.getInventory_id()).isEmpty())
			throw new InventoryNotFoundException("the order with "+inventory.getInventory_id()+"does not extis");
		return inventoryRepository.save(inventory);
		
	}

	@Override
	public void deleteInventory(int inventoryId) throws InventoryNotFoundException {
		if(inventoryRepository.findById(inventoryId).isEmpty())
			throw new InventoryNotFoundException("the order with "+inventoryId+"does not extis");
		 inventoryRepository.delete(inventoryRepository.findById(inventoryId).get());
		
	}



	@Override
	public Inventory getInventoryById(int inventoryId) throws InventoryNotFoundException {
		if(inventoryRepository.findById(inventoryId).isEmpty())
			throw new InventoryNotFoundException("the order with "+inventoryId+"does not extis");
		return inventoryRepository.findById(inventoryId).get();
	}

	
}

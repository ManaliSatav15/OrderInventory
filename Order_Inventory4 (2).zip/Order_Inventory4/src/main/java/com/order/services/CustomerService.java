package com.order.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.order.exception.CustomerNotFoundException;
import com.order.model.Customers;


public interface CustomerService {

	//public Optional<Customers> getCustomerById(int id);
	List<Customers> getAllCustomer();
	public Customers createCustomers(Customers customers);
	public	Customers updateCustomer(Customers customer) throws CustomerNotFoundException;
	public	Customers updateByCustomerId(Customers customer) throws CustomerNotFoundException;
	public String deleteCustomerById(int id);
	Customers getCustomersById(int Id) throws CustomerNotFoundException;
	void save(Customers customer);
	

    

}
package com.order.services;

import java.util.List;

import com.order.exception.InventoryNotFoundException;
import com.order.model.Inventory;


public interface InventoryService {

	Inventory getInventoryById(int inventoryId) throws InventoryNotFoundException;
	List<Inventory> getAllInventory();
	void createInventory(Inventory inventory);
	Inventory updateInventory(Inventory inventory) throws InventoryNotFoundException;
	void deleteInventory(int inventoryId) throws InventoryNotFoundException;
		

    

}
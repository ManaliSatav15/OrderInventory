package com.order.services;

import java.math.BigDecimal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.order.exception.ProductNotFoundException;
import com.order.model.Orders;
import com.order.model.Products;
import com.order.repository.ProductsRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductsRepository productsRepository;
	
	@Override
	public List<Products> getProductByName(String productName) {
		return productsRepository.findByProductNameContaining(productName);
	}

	

	@Override
	public List<Products> getAllProducts() {
		return productsRepository.findAll();
	}

	@Override
	public Products createProducts(Products products) {
		 return productsRepository.save(products);
		
	}

	@Override
	public Products updateProducts(Products products) throws ProductNotFoundException {
		if(productsRepository.findById((int) products.getProductId()).isEmpty())
			throw new ProductNotFoundException("the order with "+products.getProductId()+"does not extis");
		return productsRepository.save(products);
		
	}

	@Override
	public void deleteProducts(int productId) throws ProductNotFoundException {
		if(productsRepository.findById((int) productId).isEmpty())
			throw new ProductNotFoundException("the order with "+productId+"does not extis");
		 productsRepository.delete(productsRepository.findById((int) productId).get());
		
	}



	@Override
	public List<Products> findByProductNameContaining(String productName) {
		return productsRepository.findByProductNameContaining(productName);
	}



	@Override
	public String deleteProductById(int id) {
		
	    	String methodName = "deleteProduct()";
	    	if (productsRepository.existsById(id)) {
	    		productsRepository.deleteById(id);
				return "Record deleted Successfully";
			}
			//throw exception
			return "Deletion Failed";
		
	}



	@Override
	public String updateProduct(Products product) {
		
	        productsRepository.save(product);
	        return "Record Updated Successfully";
	    }



	@Override
	public List<Products> getProductsByUnitPriceRange(BigDecimal min, BigDecimal max) {
		
			return productsRepository.findByUnitPriceBetween(min, max);

		}



	@Override
	public List<Products> getSortedProductsByField(Sort sort) {
		
			return productsRepository.findAll(sort);
		}	
	
	
	}

	



	


		



	
	



	





	


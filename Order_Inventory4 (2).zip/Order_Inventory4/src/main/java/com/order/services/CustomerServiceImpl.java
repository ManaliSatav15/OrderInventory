package com.order.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.exception.CustomerNotFoundException;
import com.order.model.Customers;

import com.order.repository.CustomersRepository;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomersRepository customersRepository;
	
	

	@Override
	public List<Customers> getAllCustomer() {
		return customersRepository.findAll();
	}

	@Override
	public Customers createCustomers(Customers customers) {
		 return customersRepository.save(customers);
		
	}
	
//	// To update customers
//    @Override
//    public String updateCustomer(Customers customer) {
//    	customersRepository.save(customer);
//        return "Record Updated Successfully";
//    }

//	@Override
//	public Customers updateCustomer(Customers customers) throws CustomerNotFoundException {
//		if(customersRepository.findById(customers.getCustomer_id()).isEmpty())
//			throw new CustomerNotFoundException("the customer with "+customers.getCustomer_id()+"does not extis");
//		return customersRepository.save(customers);
//		
//	}
	 // To delete Customers
    @Override
    public String deleteCustomerById(int id) {
    	String methodName = "deleteCustomer()";
	//	logger.info(methodName + "called");
		if (customersRepository.existsById(id)) {
			customersRepository.deleteById(id);
			return "Record deleted Successfully";
		}
		//throw exception
		return "Deletion Failed";
    }

//	@Override
//	public void deleteCustomers(int customerId) throws CustomerNotFoundException {
//		if(customersRepository.findById(customerId).isEmpty())
//			throw new CustomerNotFoundException("the customer with "+customerId+"does not extis");
//		 customersRepository.delete(customersRepository.findById(customerId).get());
//		
//	}



//	@Override
//	public Customers getCustomerById(int customerId) throws CustomerNotFoundException {
//		if(customersRepository.findById(customerId).isEmpty())
//			throw new CustomerNotFoundException("the customer with "+customerId+"does not extis");
//		return customersRepository.findById(customerId).get();
//	}
    
  //Get customers by id
//  	@Override
//  	public Optional<Customers> getCustomerById(int id) {
//  		Optional<Customers> optionalCustomer = customersRepository.findById(id);
//  		return optionalCustomer;
//  	}

    @Override

	public Customers getCustomersById(int Id) throws CustomerNotFoundException{

 

		if(customersRepository.findById(Id).isEmpty())
			throw new CustomerNotFoundException("The Channels with"+Id+"does not exists");
		return customersRepository.findById(Id).get();
	}
    
    @Override

	public Customers updateCustomer(Customers customer) throws CustomerNotFoundException {

		int customerId = customer.getCustomer_id();

		if (customersRepository.findById(customerId).isEmpty()) {

	        throw new CustomerNotFoundException("The employee with ID " + customerId + " does not exist");

	    }

	    return customersRepository.save(customer);

	}

	@Override
	public void save(Customers customer) {
		// TODO Auto-generated method stub
		customersRepository.save(customer);
		
	}
	
	public Customers updateByCustomerId(Customers customers) throws CustomerNotFoundException {

	    // Check if the department with the specified department number exists.

	    if (customersRepository.findById(customers.getCustomer_id()).isEmpty()) {

	        throw new CustomerNotFoundException("The customer with " + customers.getCustomer_id() + " doesn't exist");

	    }

 

 

 

	    // If the department exists, update it using the repository.

	    return customersRepository.save(customers);

	}
	
	
}

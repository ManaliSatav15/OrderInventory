package com.order.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.order.dto.OrderStoreDTO;
import com.order.exception.CustomerNotFoundException;
import com.order.exception.OrderNotFoundException;
import com.order.exception.StoreNotFoundException;
import com.order.model.Customers;
import com.order.model.Orders;
import com.order.model.Stores;
import com.order.services.CustomerService;
import com.order.services.OrderService;
import com.order.services.StoreService;

@Controller
@RequestMapping("/api/v1/orders")
public class OrderController {
	
	@Autowired
	OrderService orderService;

	@Autowired
	CustomerService customerService;
	
	@Autowired
	StoreService storeService;
	
	  @GetMapping("/all")
	  public ResponseEntity<List<Orders>> getAllOrders(){
		return new ResponseEntity<List<Orders>>(orderService.getAllOrders(),HttpStatus.OK);
		  
	  }
	  
		/*
		 * @GetMapping("/{storeId}") public List<OrderStoreDTO>
		 * findByStoreId(@PathVariable int storeId){ return
		 * orderService.findByStoreId(storeId);
		 * 
		 * }
		 */
	
	  @GetMapping("/{orderId}")
		public ResponseEntity<Orders> getOrderById(@PathVariable("orderId") int orderId) throws OrderNotFoundException{
			return new ResponseEntity<Orders> (orderService.getOrderById(orderId),HttpStatus.OK);
		}
		
	
	  @GetMapping("/count/{orderStatus}")
		public ResponseEntity<Integer> getcountOfStatusByOrderStatus(@PathVariable String orderStatus) throws OrderNotFoundException{
		  int count= orderService.getcountOfStatusByOrderStatus(orderStatus);
		  return ResponseEntity.ok(count);
	}
		
	
	  @PostMapping("/Customers/{customer_id}/Stores/{storeId}")

		public ResponseEntity<Orders> createOrders(@PathVariable("customer_id") int customer_id,@PathVariable("storeId") int storeId,@RequestBody Orders orders) throws OrderNotFoundException, CustomerNotFoundException, StoreNotFoundException{

			Customers cust=customerService.getCustomersById(customer_id);

			Stores sto=storeService.getStoreById(storeId);

			orders.setCustomers(cust);

			orders.setStores(sto);

			Orders orderAdded=orderService.createOrders(orders);

			return new ResponseEntity<Orders>(orderAdded , HttpStatus.CREATED);

		}

	  @RequestMapping(value = "Customers/{customer_id}/Stores/{storeId}/update/{orderId}", method = RequestMethod.PUT)
	  public ResponseEntity<Orders> updateOrders(@PathVariable("customer_id") int customer_id,@PathVariable("storeId") int storeId,@PathVariable Orders orderId, @RequestBody Orders orders) throws OrderNotFoundException, CustomerNotFoundException, StoreNotFoundException {
	      try {
	    	  Customers cust=customerService.getCustomersById(customer_id);
	    	  Stores sto=storeService.getStoreById(storeId);
	    	  orders.setCustomers(cust);
	    	  orders.setStores(sto);
	          orders.setOrderId(orderId);
	          Orders updatedOrder = orderService.updateOrders(orders);
	          return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
	      } catch (OrderNotFoundException e) {
	          return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	      }
	  }
	 
   
	  
	  @RequestMapping(value = "Customers/{customer_id}/Stores/{storeId}/delete/{orderId}", method = RequestMethod.DELETE)
	  public ResponseEntity<String> deleteOrder(@PathVariable("customer_id") int customer_id, @PathVariable("storeId") int storeId, @PathVariable("orderId") int orderId) throws OrderNotFoundException, CustomerNotFoundException, StoreNotFoundException {
	      try {
	          Customers cust = customerService.getCustomersById(customer_id);
	          Stores sto = storeService.getStoreById(storeId);
	          
	          Orders existingOrder = orderService.getOrderById(orderId);
	          
	          if (existingOrder.getCustomers().getCustomer_id() == customer_id && existingOrder.getStores().getStoreId() == storeId) {
	              orderService.deleteOrders(orderId);
	              String message = "Order with ID " + orderId + " has been deleted successfully.";
	              return new ResponseEntity<>(message, HttpStatus.OK);
	          } else {
	              return new ResponseEntity<>("order not found", HttpStatus.NOT_FOUND);
	          }
	      } catch (OrderNotFoundException e) {
	          return new ResponseEntity<>("Order not found", HttpStatus.NOT_FOUND);
	      }
	  }

	  
	  
	  
	  
	  @GetMapping("/ordervsstore/{storeId}")
		public ResponseEntity<List<OrderStoreDTO>> getOrderAndStores(@PathVariable("storeId") int storeId) throws OrderNotFoundException{
			return new ResponseEntity<List<OrderStoreDTO>> (orderService.getOrderAndStores(storeId),HttpStatus.OK);
		}
		
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  }





	  

	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  

		
	  
	  

	

	  


package com.order.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.order.exception.CustomerNotFoundException;
import com.order.model.Customers;

import com.order.services.CustomerService;

@Controller
@RequestMapping("/api/v1/customer")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	 @GetMapping("/")
	  public ResponseEntity<List<Customers>> getAllOrders(){
		return new ResponseEntity<List<Customers>>(customerService.getAllCustomer(),HttpStatus.OK);
		  
	 }
	 
	 @DeleteMapping("/delete/{id}")
	    public ResponseEntity<String> deleteCustomerById(@PathVariable("id") int id) {
	        String resultMessage = customerService.deleteCustomerById(id);

	        if ("Record deleted Successfully".equals(resultMessage)) {
	            // Return a success response with a 200 OK status
	            return new ResponseEntity<>(resultMessage, HttpStatus.OK);
	        } else {
	            // Return an error response with a 404 Not Found status
	            return new ResponseEntity<>(resultMessage, HttpStatus.NOT_FOUND);
	        }
	    }
//	 
//	 @GetMapping("/get/{id}")
//	    public ResponseEntity<?> getCustomerById(@PathVariable("id") int id) {
//	        Customers optionalCustomer = customerService.getCustomersById(id);
//
//	        if (optionalCustomer.isPresent()) {
//	            // Return the customer with a 200 OK status
//	            return new ResponseEntity<>(optionalCustomer.get(), HttpStatus.OK);
//        } else {
//            // Return a 404 Not Found response if the customer does not exist
//	            return new ResponseEntity<>("Customer not found", HttpStatus.NOT_FOUND);
//	        }
//	    }
	 

	 @PutMapping("/{id}")

	     public ResponseEntity<Customers> updateCustomer(@PathVariable int id, @RequestBody Customers updatedCustomer) throws CustomerNotFoundException {

	         updatedCustomer.setCustomer_id(id);

			 Customers customer = customerService.updateCustomer(updatedCustomer);

			 return ResponseEntity.ok(customer);

	     }

	  
	 	   
}